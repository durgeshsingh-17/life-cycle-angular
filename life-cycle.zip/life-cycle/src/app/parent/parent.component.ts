import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.scss']
})
export class ParentComponent implements OnInit {


  // myName="Durgesh Singh";
  constructor() { }

  ngOnInit(): void { }

  myValue: string="";
  childExist: boolean = true;
  submit(val:any) {
    // alert(val);
    this.myValue = val.value
  }

  destroy() {
    this.childExist = false
  }

 
}
