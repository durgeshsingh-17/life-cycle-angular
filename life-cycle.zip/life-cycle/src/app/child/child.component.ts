import {
  AfterContentChecked,
  AfterContentInit,
  AfterViewChecked,
  AfterViewInit,
  Component,
  DoCheck,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges
} from '@angular/core';


@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.scss']
})
export class ChildComponent implements OnInit, OnChanges, DoCheck, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy {

  constructor() {
    console.log('Constructor called');
  }

  @Input() data: any;

  ngOnChanges(changes: SimpleChanges) {
    // console.log('ngOnChanges Called')
    // console.log(changes);
    console.log('ngOnChanges Called' + ' ' + changes.data.currentValue);

  }

  counter: any;
  num: number = 1;

  ngDoCheck() {
    console.log('ngDoCheck Called')
  }

  ngAfterContentInit() {
    console.log('ngAfterContentInit Called')
  }

  ngAfterContentChecked() {
    console.log('ngAfterContentChecked Called')
  }

  ngAfterViewInit() {
    console.log('ngAfterViewInit Called')
  }

  ngAfterViewChecked() {
    console.log('ngAfterViewChecked Called')
  }

  ngOnDestroy() {
    console.log('ngOnDestroy Called')
    clearInterval(this.counter)
  }

  ngOnInit() {
    console.log('ngOnInit Called');
    this.counter = setInterval(() => {
      this.num = this.num + 1;
      console.log(this.num)
      // console.log(this.counter)
    }, 1000)
  }

}
